//
// Created by yhy on 2020/10/31.
//

#include "Server.h"
#include <QtNetwork/QHostAddress>
#include <QtNetwork/QTcpSocket>
#include <QtCore/QDataStream>


Server* Server::server= nullptr;
Server::Server(QObject *parent) :QObject(parent) {
    _server= nullptr;
    _whiteSocket= nullptr;
    _blackSocket= nullptr;
    _Bblocksize=0;
    _Wblocksize=0;
}

Server* Server::GetInstance() {
    if (server== nullptr) server= new Server();
    return server;
}

void Server::Start() {
      _server=new QTcpServer(this);
      _server->listen(QHostAddress::Any,8641);
      connect(_server,&QTcpServer::newConnection, this,&Server::dealNewConn);
}

void Server::dealNewConn() {
    if(_blackSocket == nullptr){
        _blackSocket=_server->nextPendingConnection();
        connect(_blackSocket,&QTcpSocket::readyRead,this,&Server::onBReadyRead);
        connect(_blackSocket,&QTcpSocket::disconnected, this,[&](){_blackSocket= nullptr;});
    }
    else if(_whiteSocket== nullptr){
        _whiteSocket=_server->nextPendingConnection();
        connect(_whiteSocket,&QTcpSocket::readyRead,this,&Server::onWReadyRead);
        connect(_whiteSocket,&QTcpSocket::disconnected, this,[&](){_whiteSocket= nullptr;});
    }
    else return;
}

void Server::onWReadyRead(){
    QDataStream in(_whiteSocket);
    if(_Wblocksize == 0){
        if(_whiteSocket->bytesAvailable()<sizeof(int))
            return;
        in>>_Wblocksize;
    }
    if(_whiteSocket->bytesAvailable()<_Wblocksize)
        return;
    int type;
    in>>type;
    switch (type) {
        case __ready:{
            Revieve3(__white);
            break;
        }
        case __move:{
            int x,y;
            in>>x>>y;
            Revieve4(__white,x,y);
            break;
        }
        default:{
            break;
        }
    }
    _Wblocksize=0;
}

void Server::onBReadyRead(){
    QDataStream in(_blackSocket);
    if(_Bblocksize == 0){
        if(_blackSocket->bytesAvailable()<sizeof(int))
            return;
        in>>_Bblocksize;
    }
    if(_blackSocket->bytesAvailable()<_Bblocksize)
        return;
    //
    int type;
    in>>type;
    switch (type) {
        case __ready:{
            Revieve3(__black);
            break;
        }
        case __move:{
            int x,y;
            in>>x>>y;
            Revieve4(__black,x,y);
            break;
        }
        default:{
            break;
        }
    }
    _Bblocksize=0;
}

void Server::Send1(int who) {
    QTcpSocket *socket= nullptr;
    if (who==__black) socket=_blackSocket;
    else if(who==__white) socket=_whiteSocket;
    else return;
    QByteArray data;
    QDataStream dataStream(&data,QIODevice::WriteOnly);
    dataStream<<0<<__color<<who;
    dataStream.device()->seek(0);
    dataStream<<(int)(data.size()-sizeof(int));
    socket->write(data);
    qDebug()<<"send __color"<<who;
    socket->flush();
}

void Server::Send2(int who,int** a,int len) {
    QTcpSocket *socket= nullptr;
    if (who==__black) socket=_blackSocket;
    else if(who==__white) socket=_whiteSocket;
    else return;
    QByteArray data;
    QDataStream dataStream(&data,QIODevice::WriteOnly);
    dataStream<<0<<__data<<len;

    for(int i=0;i<len;i++){
        for (int j = 0; j < len; ++j) {
            dataStream<<a[i][j];
        }
    }
    dataStream.device()->seek(0);
    dataStream<<(int)(data.size()-sizeof(int));
    socket->write(data);
    qDebug()<<"send __data"<<who;
    socket->flush();
}

void Server::Revieve3(int who) {
    qDebug()<<"recieve __ready"<<who;
    emit ReportReady(who);
}

void Server::Revieve4(int who,int x,int y) {
    qDebug()<<"recieve __move"<<who<<x<<y;
    emit ReportMove(who,x,y);
}

