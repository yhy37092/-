//
// Created by yhy on 2020/10/28.
//

#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include <QtWidgets/QPushButton>
#include <QMainWindow>
#include "Game.h"
QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
Q_OBJECT
protected:
    void paintEvent(QPaintEvent *event) override;
    Game* game;
public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

public slots:
    void OnReportWin(int winner);
private:
    Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H
