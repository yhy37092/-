//
// Created by yhy on 2020/10/28.
//
#include "QDebug"
#include <QtGui/QPainter>
#include <QtWidgets/QMessageBox>
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "QMouseEvent"
#include "Server.h"
#include "rules.h"
MainWindow::MainWindow(QWidget *parent)
        : QMainWindow(parent)
        , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    game=new Game(this);
    setFixedSize(game->width*(game->interval),game->width*game->interval);
    connect(game,&Game::ReportWin, this,&MainWindow::OnReportWin);
    connect(game,&Game::update, this,[=](){update();});
    Server* server=Server::GetInstance();
    server->Start();
    connect(server,&Server::ReportReady,game,&Game::OnReportReady);
    connect(server,&Server::ReportMove,game,&Game::OnReportMove);
}

void MainWindow::OnReportWin(int winner) {
    qDebug()<<winner;
}
void MainWindow::paintEvent(QPaintEvent *event) {
    QPainter p(this);
    p.setRenderHint(QPainter::Antialiasing, true);
    int i, j;
    for (i = 0; i < game->width; i++)
    {
        p.drawLine(20, 20 + i * game->interval, game->width*game->interval-20, 20 + i * game->interval);
        p.drawLine(20 + i * game->interval, 20, 20 + game->interval * i, game->width*game->interval-20);
    }

    QBrush brush;
    brush.setStyle(Qt::SolidPattern);
    for (i = 0; i < game->width; i++)
    {
        for (j = 0; j < game->width; j++)
        {
            if (game->a[i][j] == __black)
            {
                brush.setColor(Qt::black);
                p.setBrush(brush);
                p.drawEllipse(QPoint((j) * game->interval+20, (i) * game->interval+20), 15, 15);
            }
            else if (game->a[i][j] == __white)
            {
                brush.setColor(Qt::white);
                p.setBrush(brush);
                p.drawEllipse(QPoint((j) * game->interval+20, (i) * game->interval+20), 15, 15);
            }
        }
    }
}

MainWindow::~MainWindow(){
    delete ui;
}

