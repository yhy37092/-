//
// Created by yhy on 2020/11/3.
//

#ifndef UNTITLED_RULES_H
#define UNTITLED_RULES_H
#define __black 1
#define __white -1
#define __color 2
#define __data 3
#define __win 4
#define __move 5
#define __ready 6
#endif //UNTITLED_RULES_H
