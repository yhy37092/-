//
// Created by yhy on 2020/10/31.
//

#ifndef UNTITLED_SERVER_H
#define UNTITLED_SERVER_H
#include <QtNetwork/QTcpServer>
#include <QtNetwork/QTcpSocket>
#include "rules.h"
class Server : public QObject{
    Q_OBJECT
private:
    explicit Server(QObject *parent = nullptr);
    void dealNewConn();
    int _Wblocksize;
    int _Bblocksize;
    void onWReadyRead();
    void onBReadyRead();
    static Server* server;
    QTcpServer* _server;
    QTcpSocket* _whiteSocket;
    QTcpSocket* _blackSocket;
public:
    void Send1(int who);
    void Send2(int who,int** data,int len);
    void Revieve3(int who);
    void Revieve4(int who,int x,int y);
    void Start();
    static Server* GetInstance();

    signals:
    void ReportReady(int who);
    void ReportMove(int who, int x, int y);
};


#endif //UNTITLED_SERVER_H
