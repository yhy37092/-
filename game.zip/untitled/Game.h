//
// Created by yhy on 2020/10/30.
//

#ifndef UNTITLED_GAME_H
#define UNTITLED_GAME_H

#include <QtCore/QPointF>
#include <QtCore/QVector>
#include <QtCore/QArgument>
#include "QObject"

class Game : public QObject{
    Q_OBJECT
private:
    void Init();
    int isWin(int, int);
    int f1(int, int);
    int f2(int, int);
    int f3(int, int);
    int f4(int, int);
    int player;
    bool m_RunStatus;
    bool blackready;
    bool whiteready;

public:
    int width;
    int interval;
    int **a;
    void AddPoint(int m_dx,int m_dy);
    Game(QObject *parent = nullptr);

public slots:
    void Start();
    void OnReportReady(int who);
    void OnReportMove(int who, int x, int y);
    void Stop();
    signals:
    void update();
    void ReportWin(int winner);
};


#endif //UNTITLED_GAME_H
