//
// Created by yhy on 2020/10/30.
//
#include "Game.h"
#include "rules.h"
#include "Server.h"
#include <QTime>
#include <QCoreApplication>
#include <QEvent>
Game::Game(QObject *parent) :QObject(parent){
    Init();
}

void Game::AddPoint(int m_dx, int m_dy) {
    if(m_RunStatus== false) return;
    if(m_dx>= 0 && m_dy <= width && m_dy >= 0 && m_dy <= width)
    {

        if (!a[m_dx][m_dy])
        {
            a[m_dx][m_dy] = player;
            player=-player;
        }
        if(isWin(m_dx, m_dy))
        {
            //emit ReportWin(player);
            m_RunStatus= false;
        }
    }
    emit update();
}

void Game::Start() {
    Init();
    m_RunStatus= true;
    Server::GetInstance()->Send2(__black,a,width);
    emit update();
}
void Game::Stop() {
    Init();
    m_RunStatus= false;
    emit update();
}

void Game::Init() {
    width=15;
    interval=40;
    m_RunStatus= false;
    player=__black;
    blackready= false;
    whiteready= false;
    a=(int **)malloc(sizeof(int*)*width);
    for (int i = 0; i < width; ++i) {
        a[i]=(int *) malloc(sizeof(int)*width);
    }
    for (int i = 0; i < width; ++i) {
        for (int j = 0; j < width; ++j) {
            a[i][j]=0;
        }
    }
}

int Game::isWin(int x, int y){
    return f1(x, y) || f2(x, y) || f3(x, y) || f4(x ,y);
}

int Game::f1(int x, int y)
{
    int i;
    for (i = 0; i < 5; i++)
    {
        if(y - i >= 0 &&
           y + 4 - i < width &&
           a[x][y - i] == a[x][y + 1 - i] &&
           a[x][y - i] == a[x][y + 2 - i] &&
           a[x][y - i] == a[x][y + 3 - i] &&
           a[x][y - i] == a[x][y + 4 - i])
            return 1;
    }
    return 0;
}

int Game::f2(int x, int y)
{
    int i;
    for (i = 0; i < 5; i++)
    {
        if(x - i >= 0 &&
           x + 4 - i < width &&
           a[x - i][y] == a[x + 1 - i][y] &&
           a[x - i][y] == a[x + 2 - i][y] &&
           a[x - i][y] == a[x + 3 - i][y] &&
           a[x - i][y] == a[x + 4 - i][y])
            return 1;
    }
    return 0;
}

int Game::f3(int x, int y)
{
    int i;
    for (i = 0; i < 5; i++)
    {
        if(x - i >= 0 &&
           y - i >= 0 &&
           x + 4 - i < width &&
           y + 4 - i < width &&
           a[x - i][y - i] == a[x + 1 - i][y + 1 - i] &&
           a[x - i][y - i] == a[x + 2 - i][y + 2 - i] &&
           a[x - i][y - i] == a[x + 3 - i][y + 3 - i] &&
           a[x - i][y - i] == a[x + 4 - i][y + 4 - i])
            return 1;
    }
    return 0;
}

int Game::f4(int x, int y)
{
    int i;
    for (i = 0; i < 5; i++)
    {
        if(x + i < width &&
           y - i >= 0 &&
           x - 4 + i >= 0 &&
           y + 4 - i < width &&
           a[x + i][y - i] == a[x - 1 + i][y + 1 - i] &&
           a[x + i][y - i] == a[x - 2 + i][y + 2 - i] &&
           a[x + i][y - i] == a[x - 3 + i][y + 3 - i] &&
           a[x + i][y - i] == a[x - 4 + i][y + 4 - i])
            return 1;
    }
    return 0;
}

void Game::OnReportReady(int who){
    if(__black==who&&blackready== false) {
        blackready= true;
        Server::GetInstance()->Send1(who);
    }else if(__black==who&&blackready== true){
        blackready= false;
        Stop();
        return;
    }
    if(__white==who&&whiteready== false) {
        whiteready= true;
        Server::GetInstance()->Send1(who);
    }else if (__white==who&&whiteready== true){
        whiteready= false;
        Stop();
        return;
    }
    if(whiteready&&blackready){
        QTime dietime=QTime::currentTime().addMSecs(1000);
        while (QTime::currentTime()<dietime)
            QCoreApplication::processEvents(QEventLoop::AllEvents,100);
        Start();
    }
}

void Game::OnReportMove(int who, int x, int y){
    if(m_RunStatus== false) return;
    if(player==who) AddPoint(x,y);
    if(m_RunStatus==true)
    Server::GetInstance()->Send2(player,a,width);
}

