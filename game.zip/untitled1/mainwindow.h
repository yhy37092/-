//
// Created by yhy on 2020/11/3.
//

#ifndef UNTITLED1_MAINWINDOW_H
#define UNTITLED1_MAINWINDOW_H

#include <QMainWindow>
#include <QtWidgets/QPushButton>
#include "Game.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class Mainwindow : public QMainWindow{
    Q_OBJECT
protected:
    void paintEvent(QPaintEvent *event) override;

    void mousePressEvent(QMouseEvent *event) override;

public:
    Mainwindow(QWidget *parent = nullptr);
    QPointF gainPointPosition(QPointF srcPoint);
    ~Mainwindow();

    bool eventFilter(QObject *watched, QEvent *event) override;

private:
    QPushButton *btn_ready;
    QPushButton *btn_switch;
    Game* game;
    Ui::MainWindow *ui;
    void OnReportWin();

public slots:
    void OnRepaint();
};


#endif //UNTITLED1_MAINWINDOW_H
