//
// Created by yhy on 2020/11/3.
//

#ifndef UNTITLED1_CLIENT_H
#define UNTITLED1_CLIENT_H
#include <QtNetwork/QTcpSocket>

class Client : public QObject{
    Q_OBJECT
private:
    int _blocksize;
    void onReadyRead();
    QTcpSocket* _Socket;
    static Client* client;
    Client(QObject* parent= nullptr);
public:
    void Send1();
    void Send2(int x,int y);
    void Revieve3(int **a);
    void Revieve4(int who);
    static Client* GetInstance();
    void Start();
signals:
    void ReportColor(int who);
    void ReportData(int **pInt);

public slots:
    void ReadError(QAbstractSocket::SocketError);
};


#endif //UNTITLED1_CLIENT_H
