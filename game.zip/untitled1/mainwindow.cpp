//
// Created by yhy on 2020/11/3.
//

#include <QtGui/QPainter>
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMoveEvent>
#include "Client.h"
#include "rules.h"
Mainwindow::Mainwindow(QWidget *parent)
        : QMainWindow(parent)
        , ui(new Ui::MainWindow) {
    ui->setupUi(this);
    game=new Game(this);
    btn_ready=new QPushButton(this);
    btn_switch=new QPushButton(this);
    btn_switch->setGeometry(game->interval*game->width, game->interval*game->width-game->interval*2, game->interval*2, game->interval);
    btn_ready->setGeometry(game->interval*game->width/2-game->interval*2, game->interval*game->width/2, game->interval*4, game->interval*2);
    QFont qFont;
    qFont.setBold(true);
    qFont.setPointSize(20);
    btn_ready->setFont(qFont);
    btn_switch->setFont(qFont);
    btn_ready->setText("准备");
    btn_switch->setText("人");
    btn_ready->installEventFilter(this);
    btn_switch->installEventFilter(this);
    setFixedSize(game->width*(game->interval)+100,game->width*game->interval);
    connect(game,&Game::ReportWin, this,&Mainwindow::OnReportWin);
    connect(game,&Game::update, this,&Mainwindow::OnRepaint);
    Client* client=Client::GetInstance();
    connect(client,&Client::ReportData,game,&Game::OnReportData);
    connect(client,&Client::ReportColor,game,&Game::OnReportColor);
}

bool Mainwindow::eventFilter(QObject *watched, QEvent *event) {

    if(watched==btn_ready&&event->type()==QEvent::MouseButtonRelease){
        emit game->Start();
        btn_ready->hide();
    }
    if(watched==btn_switch&&event->type()==QEvent::MouseButtonRelease){
        if(game->ai== true){
            game->ai= false;
            btn_switch->setText("人");
        } else{
            game->ai= true;
            btn_switch->setText("机");
        }
    }
    return QObject::eventFilter(watched, event);
}

Mainwindow::~Mainwindow(){
    delete ui;
}

void Mainwindow::mousePressEvent(QMouseEvent *event) {
    QPointF point(event->y()-20,event->x()-20);
    point=gainPointPosition(point);
    game->AddPoint(point.x()/game->interval,point.y()/game->interval);
}
QPointF Mainwindow::gainPointPosition(QPointF srcPoint){
    QPointF tmp;
    for(int i = 0;i < game->width;i++)
    {
        if(srcPoint.x() >= game->interval*i && srcPoint.x() <= (game->interval*i+game->interval/2))//X判断
        {
            tmp.setX(game->interval*i);//如果处于50*i ~ 50*i+25）之间则设置点坐标点为50*i
        }
        else if (srcPoint.x() >= (game->interval*i + game->interval/2) && srcPoint.x() <= game->interval*(i+1))
        {
            tmp.setX(game->interval*(i+1));//如果处于50*i+25 ~ 50*(i+1)之间则设置点坐标点为50*(i+1)
        }
        if(srcPoint.y() >= game->interval*i && srcPoint.y() <= (game->interval*i+game->interval/2))//Y判断
        {
            tmp.setY(game->interval*i);//同上
        }
        else if (srcPoint.y() >= (game->interval*i + game->interval/2) && srcPoint.y() <= game->interval*(i+1))
        {
            tmp.setY(game->interval*(i+1));//同上
        }
    }
    return tmp;
}

void Mainwindow::paintEvent(QPaintEvent *event) {
    QPainter p(this);
    p.setRenderHint(QPainter::Antialiasing, true);
    int i, j;
    for (i = 0; i < game->width; i++)
    {
        p.drawLine(20, 20 + i * game->interval, game->width*game->interval-20, 20 + i * game->interval);
        p.drawLine(20 + i * game->interval, 20, 20 + game->interval * i, game->width*game->interval-20);
    }

    QBrush brush;
    brush.setStyle(Qt::SolidPattern);
    for (i = 0; i < game->width; i++)
    {
        for (j = 0; j < game->width; j++)
        {
            if (game->a[i][j] == __black)
            {
                brush.setColor(Qt::black);
                p.setBrush(brush);
                p.drawEllipse(QPoint((j) * game->interval+20, (i) * game->interval+20), 15, 15);
            }
            else if (game->a[i][j] == __white)
            {
                brush.setColor(Qt::white);
                p.setBrush(brush);
                p.drawEllipse(QPoint((j) * game->interval+20, (i) * game->interval+20), 15, 15);
            }
        }
    }
}
void Mainwindow::OnReportWin() {
    btn_ready->show();
}
void Mainwindow::OnRepaint(){
    repaint();
}