//
// Created by yhy on 2020/11/3.
//

#include <QtCore/QDataStream>
#include "Client.h"
#include "rules.h"
#include <QMessageBox>
Client* Client::client= nullptr;
Client::Client(QObject *parent) {
    _blocksize=0;
    _Socket=new QTcpSocket();
}
void Client::Start(){
    _Socket->connectToHost("127.0.0.1",8641);
    if(!_Socket->waitForConnected()) {
        QMessageBox::information(nullptr,"错误","连接失败");
        qDebug() << "连接失败";
        return;
    }
    connect(_Socket,&QTcpSocket::readyRead, this,&Client::onReadyRead);
    connect(_Socket,QOverload<QAbstractSocket::SocketError>::of(&QAbstractSocket::error),this,&Client::ReadError);
}
void Client::onReadyRead(){
    QDataStream in(_Socket);
    if(_blocksize == 0){
        if(_Socket->bytesAvailable()<sizeof(int))
            return;
        in>>_blocksize;
    }
    if(_Socket->bytesAvailable()<_blocksize)
        return;
    //
    int type;
    in>>type;
    switch (type) {
        case __color:{
            int who;
            in>>who;
            Revieve4(who);
            break;
        }
        case __data:{
            int len;
            in>>len;
            int **a=(int **)malloc(sizeof(int*)*(len+1));
            for (int i = 0; i < len; ++i) {
                a[i]=(int *) malloc(sizeof(int)*(len+1));
            }
            for (int i = 0; i < len; ++i) {
                for (int j = 0; j < len; ++j) {
                    in>>a[i][j];
                }
            }
            Revieve3(a);
            break;
        }
        default:{
            break;
        }
    }

    _blocksize=0;
}
Client* Client::GetInstance() {
    if(client== nullptr) client=new Client();
    return client;
}
void Client::Send1() {
    QByteArray data;
    QDataStream dataStream(&data,QIODevice::WriteOnly);
    dataStream<<0<<__ready;
    dataStream.device()->seek(0);
    dataStream<<(int)(data.size()-sizeof(int));
    _Socket->write(data);
    qDebug()<<"send __ready";
    _Socket->flush();
}
void Client::Send2(int x,int y){
    QByteArray data;
    QDataStream dataStream(&data,QIODevice::WriteOnly);
    dataStream<<0<<__move<<x<<y;
    dataStream.device()->seek(0);
    dataStream<<(int)(data.size()-sizeof(int));
    _Socket->write(data);
    qDebug()<<"send __move"<<x<<y;
    _Socket->flush();
}
void Client::Revieve3(int **a){
    qDebug()<<"recieve __data";
    emit ReportData(a);
}
void Client::Revieve4(int who){
    qDebug()<<"recieve __who"<<who;
    emit ReportColor(who);
}
void Client::ReadError(QAbstractSocket::SocketError socketError)
{QMessageBox::information(nullptr,"错误","读取失败");}

