//
// Created by yhy on 2020/10/30.
//

#ifndef UNTITLED_GAME_H
#define UNTITLED_GAME_H

#include <QtCore/QPointF>
#include <QtCore/QVector>
#include <QtCore/QArgument>
#include "QObject"
#include "ArtificialIntelligence.h"

class Game : public QObject{
    Q_OBJECT
private:

    int player;
    ArtificialIntelligence *Ai;

public:
    bool m_status;
    void AddPoint(int m_dx,int m_dy);
    bool ai;
    int width;
    int interval;
    int **a;
    Game(QObject *parent = nullptr);

public slots:
    void Start();
    void OnReportColor(int who);
    void OnReportData(int **pInt);
    signals:
    void update();
    void ReportWin(int winner);
};


#endif //UNTITLED_GAME_H
