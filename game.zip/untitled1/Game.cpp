//
// Created by yhy on 2020/10/30.
//
#include "Game.h"
#include "Client.h"
Game::Game(QObject *parent) :QObject(parent){
    width=15;
    interval=40;
    ai= false;
    a=(int **)malloc(sizeof(int*)*width);
    for (int i = 0; i < width; ++i) {
        a[i]=(int *) malloc(sizeof(int)*width);
    }
    for (int i = 0; i < width; ++i) {
        for (int j = 0; j < width; ++j) {
            a[i][j]=0;
        }
    }
}
void Game::Start() {
    m_status= false;
    player=0;
    Ai=new ArtificialIntelligence();
    Client::GetInstance()->Start();
    Client::GetInstance()->Send1();
}


void Game::AddPoint(int x, int y) {
    if(m_status== false) return;
    if(x >= 0 && x <= width && y >= 0 && y <= width)
    {
        qDebug()<<x<<y;
        if (!a[x][y])
        {
            a[x][y] = player;
        }
    }
    Client::GetInstance()->Send2(x,y);
    emit update();
    m_status= false;
}
void Game::OnReportColor(int who){
    player=who;
}
void Game::OnReportData(int **pInt){
    delete [] this->a;
    this->a=pInt;
    m_status= true;
    if(ai== true){
        Position position= Ai->alphabeta(a,3,INT_MIN,INT_MAX,player);
        qDebug()<<position.x<<position.y<<position.score;
        AddPoint(position.x,position.y);
        }
    emit update();
}















